package GUI;

/**
 *
 * @author javier
 */
public class Borrame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        VPpal v=new VPpal();
        v.setSize(300,400);
        v.setLocationRelativeTo(null);
        v.setVisible(true);
    }
    
}
